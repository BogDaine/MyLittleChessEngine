#pragma once
#include <string>
#include <iostream>
#include "Search.h"
#define COMMAND_LENGTH 511

void command_loop();