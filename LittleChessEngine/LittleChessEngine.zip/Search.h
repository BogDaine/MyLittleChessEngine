#pragma once
#include "Eval.h"

long perft(const int& maxDepth, const int& depth);